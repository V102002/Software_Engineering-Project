const express = require('express');
const { Pool } = require('pg');

const app = express();
const port = 3037;
// PostgreSQL configuration
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'teammuch',
    password: 'tejas1116',
    port: 5432,
});

// Test PostgreSQL connection
pool.connect((err) => {
    if (err) {
        console.error('Error connecting to PostgreSQL:', err);
    } else {
        console.log('Connected to PostgreSQL database');
    }
});

app.set('view engine', 'ejs');
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index'); // Render index.ejs from the 'views' directory
});

// Route to render the initial projects page
app.get('/projects/:deptId', async (req, res) => {
    const { deptId } = req.params;
    try {
        const { rows } = await pool.query('SELECT * FROM projects WHERE dept_id = $1', [deptId]);
        res.render('projects', { projects: rows });
    } catch (err) {
        console.error('Error executing query', err);
        res.status(500).send('Internal Server Error');
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

